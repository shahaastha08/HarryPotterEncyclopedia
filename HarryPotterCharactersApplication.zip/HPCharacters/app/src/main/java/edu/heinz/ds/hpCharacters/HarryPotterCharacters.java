/*
Name: Aastha Shah
Andrew id: aasthash
 */

package edu.heinz.ds.hpCharacters;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


/*
This class controls the activities on the Android application and displays the response from the Server on the application screen.
 */
public class HarryPotterCharacters extends AppCompatActivity {

    HarryPotterCharacters me = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
         * The click listener will need a reference to this object, so that upon successfully finding a picture from Flickr, it
         * can callback to this object with the resulting picture Bitmap.  The "this" of the OnClick will be the OnClickListener, not
         * this InterestingPicture.
         */
        final HarryPotterCharacters ma = this;

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button)findViewById(R.id.submit);


        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                String searchTerm = ((EditText)findViewById(R.id.searchTerm)).getText().toString();
                System.out.println("searchTerm = " + searchTerm);
                GetCharacterDetails gcd = new GetCharacterDetails();
                gcd.search(searchTerm, me, ma); // Done asynchronously in another thread.  It calls ip.pictureReady() in this thread when complete.
            }
        });
    }

    /*
     * This is called by the GetCharacterDetails object when the response is ready.
     * This allows for passing back the response and Bitmap image to display on Text View and ImageView respectively.
     */
    public void responseReady(Response response, Bitmap picture) {
        ImageView pictureView = (ImageView)findViewById(R.id.interestingPicture);
        TextView searchView = (EditText)findViewById(R.id.searchTerm);
        TextView feedbackView = (TextView) findViewById(R.id.feedBack);
        TextView charName = (TextView) findViewById(R.id.charName);
        TextView house = (TextView) findViewById(R.id.house);
        TextView dob = (TextView) findViewById(R.id.dob);
        TextView ancestry = (TextView) findViewById(R.id.ancestry);
        TextView actor = (TextView) findViewById(R.id.actorName);
        TextView eyeColor = (TextView) findViewById(R.id.eyeColor);
        TextView patronus = (TextView) findViewById(R.id.patronus);

        if (response!=null) {

            //If we get a valid response, update the parameters and check for error handling and null values
            if (picture!=null){
                pictureView.setImageBitmap(picture); // Send picture as bitmap
            }else{
                pictureView.setImageResource(R.mipmap.ic_launcher);
            }
            charName.setText("Character Name: "+response.getCharName());

            if (response.getHouse()==null || response.getHouse().equals("")){
                house.setText("Hogwart's House: "+"Not Found");
            }else{
                house.setText("Hogwart's House: "+response.getHouse());
            }

            if (response.getDob()==null){
                dob.setText("Date of Birth: "+"Not Found");
            }else{
                dob.setText("Date of Birth: "+response.getDob());
            }

            if (response.getAncestry()==null || response.getAncestry().equals("")){
                ancestry.setText("Ancestry: "+"Not Found");
            } else{
                ancestry.setText("Ancestry: "+response.getAncestry());
            }

            if(response.getActorName() == null || response.getActorName().equals("")){
                actor.setText("Actor Name: "+"Not Found");
            }else{
                actor.setText("Actor Name: "+response.getActorName());
            }

            if (response.getEyeColor()== null || response.getEyeColor().equals("")){
                eyeColor.setText("Eye Color: "+"Not Found");
            }else {
                eyeColor.setText("Eye Color: "+response.getEyeColor());
            }

            if (response.getPatronus().equals("")){
                patronus.setText("Patronus: "+"Not Found");
            }else{
                patronus.setText("Patronus: "+response.getPatronus());
            }

            pictureView.setVisibility(View.VISIBLE);
            charName.setVisibility(View.VISIBLE);
            house.setVisibility(View.VISIBLE);
            dob.setVisibility(View.VISIBLE);
            ancestry.setVisibility(View.VISIBLE);
            actor.setVisibility(View.VISIBLE);
            eyeColor.setVisibility(View.VISIBLE);
            patronus.setVisibility(View.VISIBLE);

            feedbackView.setText("Here is your information on "+searchView.getText());
        } else {
            pictureView.setImageResource(R.mipmap.ic_launcher);
            pictureView.setVisibility(View.INVISIBLE);
            feedbackView.setText("Sorry, I could not find information on "+searchView.getText());
            charName.setVisibility(View.INVISIBLE);
            house.setVisibility(View.INVISIBLE);
            dob.setVisibility(View.INVISIBLE);
            ancestry.setVisibility(View.INVISIBLE);
            actor.setVisibility(View.INVISIBLE);
            eyeColor.setVisibility(View.INVISIBLE);
            patronus.setVisibility(View.INVISIBLE);

        }
        searchView.setText("");
        pictureView.invalidate();
    }
}

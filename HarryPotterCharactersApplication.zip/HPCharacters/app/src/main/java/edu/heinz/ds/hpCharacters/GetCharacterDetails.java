/*
Name: Aastha Shah
Andrew id: aasthash
 */

package edu.heinz.ds.hpCharacters;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
//import android.os.Build;
//import android.support.annotation.RequiresApi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import androidx.annotation.RequiresApi;

import com.google.gson.Gson;

/*
 * This class provides capabilities to search for information about Harry Potter Characters given a character name.  The method "search" is the entry to the class.
 * Network operations cannot be done from the UI thread, therefore this class makes use of inner class BackgroundTask that will do the network
 * operations in a separate worker thread.  However, any UI updates should be done in the UI thread so avoid any synchronization problems.
 * onPostExecution runs in the UI thread, and it calls the responseReady method to do the update.
 * 
 * Method BackgroundTask.doInBackground( ) does the background work
 * Method BackgroundTask.onPostExecute( ) is called when the background work is
 *    done; it calls *back* to ip to report the results
 *
 */
public class GetCharacterDetails {
    HarryPotterCharacters hp = null;   // for callback
    String searchTerm = null;       // searchChar to be sent as Query Parameter to the API request
    Bitmap picture = null;          // to store the image returned by the image URL

    String response = ""; //to store the JSON response string from the server

    Response response_object = null; //response object to store and access the character information

    // search( )
    // Parameters:
    // String searchTerm: the character for which information is to be requested
    // Activity activity: the UI thread activity
    // HarryPotterCharacters hp: the callback method's class; here, it will be hp.responseReady( )
    public void search(String searchTerm, Activity activity, HarryPotterCharacters hp) {
        this.hp = hp;
        this.searchTerm = searchTerm;
        new BackgroundTask(activity).execute();
    }

    // class BackgroundTask
    // Implements a background thread for a long running task that should not be
    //    performed on the UI thread. It creates a new Thread object, then calls doInBackground() to
    //    actually do the work. When done, it calls onPostExecute(), which runs
    //    on the UI thread to update some UI widget (***never*** update a UI
    //    widget from some other thread!)
    //
    // Adapted from one of the answers in
    // https://stackoverflow.com/questions/58767733/the-asynctask-api-is-deprecated-in-android-11-what-are-the-alternatives
    // Modified by Martin Barrett
    //
    // Ideally, this class would be abstract and parameterized.
    // The class would be something like:
    //      private abstract class BackgroundTask<InValue, OutValue>
    // with two generic placeholders for the actual input value and output value.
    // It would be instantiated for this program as
    //      private class MyBackgroundTask extends BackgroundTask<String, Bitmap>
    // where the parameters are the String url and the Bitmap image.
    //    (Some other changes would be needed, so I kept it simple.)
    //    The first parameter is what the BackgroundTask looks up on Flickr and the latter
    //    is the image returned to the UI thread.
    // In addition, the methods doInBackground() and onPostExecute( ) could be
    //    absttract methods; would need to finesse the input and ouptut values.
    // The call to activity.runOnUiThread( ) is an Android Activity method that
    //    somehow "knows" to use the UI thread, even if it appears to create a
    //    new Runnable.

    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {

                    doInBackground();
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        private void execute(){
            // There could be more setup here, which is why
            //    startBackground is not called directly
            startBackground();
        }

        // doInBackground( ) implements whatever you need to do on
        //    the background thread.
        // Implement this method to suit your needs
        private void doInBackground() {
            response = search(searchTerm);
//            System.out.println(response);
            Gson gson = new Gson();
            if(!response.equalsIgnoreCase("Bad Request")){
                response_object = gson.fromJson(response, Response.class);
            }
            if (response_object!=null){
                try {
                    picture = getRemoteImage(new URL(response_object.getImageURL()));
                } catch (MalformedURLException e) {
                    picture = null;
                }
            }
        }

        // onPostExecute( ) will run on the UI thread after the background
        //    thread completes.
        // Implement this method to suit your needs
        public void onPostExecute() {
            hp.responseReady(response_object, picture); //responseReady takes the response object as well as the Bitmap picture as parameters
        }

        /*
         * Send an API request to the server to get the character information
         */
        private String search(String searchTerm) {
            String response = null;
            //processing the search Term for robustness
            String updated_search_term = capitalizeWord(searchTerm).replaceAll(" ", "%20");

            try {
                // Create a URL object and open a connection to it
                URL url = new URL("https://aasthashah0897-didactic-space-winner-pv5wr4746jp2r65g-8080.preview.app.github.dev/hp-character-encyclopedia?searchChar="+updated_search_term);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                // Set the request method and headers
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Accept", "application/json");

                // Read the response from the server

                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                String line;
                StringBuffer responseString = new StringBuffer();

                while ((line = reader.readLine()) != null) {
                    responseString.append(line);
                }
                reader.close();

                // Store the response from the server
                response = responseString.toString();

                // Disconnect from the servlet
                urlConnection.disconnect();

            } catch (IOException e) {
                e.printStackTrace();
            }

            return response;
        }


        /*
         * Given a URL referring to an image, return a bitmap of that image
         */
        @RequiresApi(api = Build.VERSION_CODES.P)
        private Bitmap getRemoteImage(final URL url) {
            try {
                final URLConnection conn = url.openConnection();
                conn.connect();
                BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
                Bitmap bm = BitmapFactory.decodeStream(bis);
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        //Code taken from
        /*https://www.javatpoint.com/java-program-to-capitalize-each-word-in-string*/
        public String capitalizeWord(String str){
            String words[]=str.split("\\s");
            String capitalizeWord="";
            for(String w:words){
                String first=w.substring(0,1);
                String afterfirst=w.substring(1);
                capitalizeWord+=first.toUpperCase()+afterfirst+" ";
            }
            return capitalizeWord.trim();
        }

    }
}


/*
Name: Aastha Shah
Andrew id: aasthash
 */

/*
 *
 * This file is the Model component of the MVC, and it models the business
 * logic for the servlet.  In this case, the business logic involves
 * making a request to the Harry Potter API and receive a response and parse the JSON response into an object.
 * It also sends the required data to HPServlet.java based on the GET request given by the Mobile application user.
 */


package com.example.task2servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;
import org.bson.Document;


public class HPModel {

    //Initializing the collection to store data with MongoDB
    MongoCollection<Document> collection;

    public MongoCollection<Document> getCollection() {
        return collection;
    }

    public HPModel() {

        //Connecting to MongoDB
        String uri = "mongodb://aasthash:DSProject4Task2@ac-q5uyi2g-shard-00-00.djtke9x.mongodb.net:27017,ac-q5uyi2g-shard-00-01.djtke9x.mongodb.net:27017,ac-q5uyi2g-shard-00-02.djtke9x.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        MongoClient mongoClient = MongoClients.create(uri);

        //Accessing the hp_logs_project4 database
        MongoDatabase database = mongoClient.getDatabase("hp_logs_project4");
        collection = database.getCollection("hp_logs");
    }

    //This method takes the searchString from the GET request as a parameter.
    //It returns a JSON String with the required parameters
    public String getData(String searchString) {

        ArrayList<HarryPotter> characters = new ArrayList<>();
        String messageToSend = new String();

        try {
            // Create a URL object for the API endpoint
            String  url = "https://hp-api.onrender.com/api/characters";
            String response = fetch(url);

            //Converting the JSON String to HarryPotter class object and appending the object to an ArrayList
            Gson gson = new Gson();
            Type userListType = new TypeToken<ArrayList<HarryPotter>>(){}.getType();
            characters = gson.fromJson(String.valueOf(response), userListType);

            //Creating a HashMap to map the details to the Character Name
            HashMap<String, HarryPotter>  charMap = new HashMap<>();
            for (HarryPotter character: characters){
                charMap.put(character.getName(), character);
            }

            //Initializing the Response object to be converted to a JSON String
            //and sent as a response to the mobile application
            Response responseString = new Response();

            if (charMap.containsKey(searchString)){
                responseString.setCharName(charMap.get(searchString).getName());
                responseString.setHouse(charMap.get(searchString).getHouse());
                responseString.setDob(charMap.get(searchString).getDateOfBirth());
                responseString.setAncestry(charMap.get(searchString).getAncestry());
                responseString.setImageURL(charMap.get(searchString).getImage());
                responseString.setPatronus(charMap.get(searchString).getPatronus());
                responseString.setActorName(charMap.get(searchString).getActor());
                responseString.setEyeColor(charMap.get(searchString).getEyeColour());
                responseString.setHairColor(charMap.get(searchString).getHairColour());

                //ResponseString containing the JSON response
                messageToSend = gson.toJson(responseString);
            }
            else{
                messageToSend = "Bad Request";
            }
        } catch (Exception e) {
            //Error Handling for no response from 3rd party API
            System.out.println("Error: Did not receive response from the 3rd Party API");
        }
        return messageToSend;
    }

    //This method fetched the JSON response string from the 3rd Party API
    private String fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("Eeek, an exception");
        }
        return response;
    }

}

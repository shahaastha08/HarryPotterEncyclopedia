/*
Name: Aastha Shah
Andrew id: aasthash
 */

/*
This class is responsible to handle the GET requests from the mobile application and the Web browser.
It has two paths - /hp-character-encyclopedia handles the GET requests from the mobile application.
/showDashboard displays the Dashboard on a web browser
 */

package com.example.task2servlet;

import java.io.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.mongodb.client.MongoCursor;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;

@WebServlet(name = "hpServlet", urlPatterns = {"/hp-character-encyclopedia", "/showDashboard"})
public class HPServlet extends HttpServlet {
    HPModel model = null;

    private static int requestCount = 0;

    public void init() {
        model = new HPModel(); //Initializing the HPModel object
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String requestedUrl = request.getRequestURI();
        System.out.println(requestedUrl);
        String nextView = new String();

        //Code to process GET requests from the application
        if (requestedUrl.endsWith("/hp-character-encyclopedia")) {

            //Timestamp of request
            Timestamp requestTime = new Timestamp(System.currentTimeMillis());
            System.out.println(requestTime);

            //Request Number
            requestCount++;
            int requestNumber = requestCount;
            System.out.println(requestNumber);

            //User Device Type
            String ua = request.getHeader("User-Agent");
            System.out.println(ua);

            //Getting the searchString from the Query Parameter
            String searchString = request.getParameter("searchChar");

            long startTime = System.currentTimeMillis();
            String responseString = model.getData(searchString); //Calling the getData method to get appropriate response from the 3rd party API

            long endTime = System.currentTimeMillis();

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            request.setAttribute("responseString", responseString); //Setting the responseString

            //Response Status
            String responseStatus;
            if (responseString == "Bad Request") {
                responseStatus = "Failure";
            } else {
                responseStatus = "Success";
            }

            nextView = "index.jsp";

            //Request Processing Time
            long processingTime = endTime - startTime;

            //Saving the log details in the MongoDB document
            Document document = new Document("requestNumber", String.valueOf(requestNumber));
            document.append("userDevice", ua);
            document.append("timestamp", requestTime);
            document.append("searchString", searchString);
            document.append("processingTime", processingTime);
            document.append("responseStatus", responseStatus);
            model.getCollection().insertOne(document); //inserting the document to a collection

        }
        else if (requestedUrl.endsWith("/showDashboard")) {

            List<String[]> data = new ArrayList<>(); //Creating a list to fill in data in the logs table
            //Creating a Map to count the number of searches
            Map<String, Integer> countSearchString = new HashMap<String, Integer>();
            MongoCursor<Document> cursor = model.getCollection().find().iterator();
            int total_requests = 0; //Total Number of requests
            long total_lag = 0; //total_processing_time

            while (cursor.hasNext()) {

                //Retrieve data from the MongoDB database
                Document retrievedDocument = cursor.next();
                String requestNumber = retrievedDocument.get("requestNumber").toString();
                String userDevice = retrievedDocument.getString("userDevice");
                String timestamp = retrievedDocument.get("timestamp").toString();
                String searchString = retrievedDocument.getString("searchString");

                //Count the number of requests for a particular character
                if (countSearchString.containsKey(searchString)) {
                    countSearchString.put(searchString, countSearchString.get(searchString) + 1);
                    } else {
                    countSearchString.put(searchString, 1);
                    }

                String processingTime = retrievedDocument.get("processingTime").toString();
                total_lag += Long.parseLong(String.valueOf(retrievedDocument.get("processingTime")));
                String responseStatus = retrievedDocument.getString("responseStatus");

                data.add(new String[]{requestNumber, userDevice, timestamp, searchString, processingTime, responseStatus});
                // Set the data as an attribute of the request object
                request.setAttribute("data", data);
                total_requests++; //Counting total number of requests
            }

            //Total Number of Requests
            request.setAttribute("totalRequests", total_requests);

            //Top 5 Characters searched
            /*Referred to: https://stackoverflow.com/questions/30425836/java-8-stream-map-to-list-of-keys-sorted-by-values*/
            List<Map.Entry<String, Integer>> sortedEntries = countSearchString.entrySet()
                    .stream()
                    .sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue()))
                    .limit(5)
                    .collect(Collectors.toList());

            request.setAttribute("top5Searches", sortedEntries);

            //Unique Requests
            request.setAttribute("uniqueRequests", countSearchString.size());

            //Average Processing Time
            long avgProcessingTime = total_lag/total_requests;
            request.setAttribute("avgProcessingTime", avgProcessingTime);
            nextView = "dashboard.jsp";
        }
            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }

        public void destroy () {
        }
}
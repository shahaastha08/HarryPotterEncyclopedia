/*
Name: Aastha Shah
Andrew id: aasthash
 */

/*
This class is used to store the details of the wand of the character
 */

package com.example.task2servlet;

public class Wand {
    private String wood;
    private String core;
    private float length;



    public String getWood() {
        return wood;
    }

    public void setWood(String wood) {
        this.wood = wood;
    }

    public String getCore() {
        return core;
    }

    public void setCore(String core) {
        this.core = core;
    }

    public double getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }


    // getters and setters omitted for brevity
}
